# Contributing

Gracias por querer contribuir. Por favor:

1. Haz un fork del repositorio.
2. Crea una rama con un nombre descriptivo: `feature/tu-cambio`.
3. Haz commits claros y descriptivos.
4. Abre un Pull Request explicando los cambios.

Para cambios en `simple-interest.sh`, añade pruebas o ejemplos en el README.
