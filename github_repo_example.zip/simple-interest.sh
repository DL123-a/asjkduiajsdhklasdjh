#!/usr/bin/env bash
# simple-interest.sh
# Calcula interés simple: I = P * r * t
# Uso: ./simple-interest.sh principal tasa_anual_porcentaje tiempo_en_años
# Si no se proporciona tiempo, se asume 1 año.

set -e

if [ "$#" -lt 2 ]; then
  echo "Uso: $0 principal tasa_anual_porcentaje [tiempo_en_años]"
  exit 1
fi

P=$1
r_percent=$2
t=${3:-1}

# Validar números
re='^-?[0-9]+([.][0-9]+)?$'
if ! [[ $P =~ $re && $r_percent =~ $re && $t =~ $re ]]; then
  echo "Error: los argumentos deben ser números."
  exit 1
fi

r=$(echo "scale=10; $r_percent / 100" | bc -l)
I=$(echo "scale=10; $P * $r * $t" | bc -l)
total=$(echo "scale=10; $P + $I" | bc -l)

echo "Principal: $P"
echo "Tasa anual (%): $r_percent"
echo "Tiempo (años): $t"
echo "Interés simple: $I"
echo "Total (principal + interés): $total"
