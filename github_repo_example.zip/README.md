# Proyecto: Repositorio de ejemplo para la tarea

Este repositorio contiene los archivos solicitados por la actividad:
- LICENSE (Apache 2.0)
- README.md (este archivo)
- CODE_OF_CONDUCT.md
- CONTRIBUTING.md
- simple-interest.sh

## simple-interest.sh
Script sencillo para calcular interés simple:
Uso:
```bash
./simple-interest.sh principal tasa_anual porcentaje tiempo_años
```
Ejemplo:
```bash
./simple-interest.sh 1000 5  # calcula interés de 5% anual sobre 1000 por 1 año por defecto
```

## Estructura
- LICENSE
- README.md
- CODE_OF_CONDUCT.md
- CONTRIBUTING.md
- simple-interest.sh

