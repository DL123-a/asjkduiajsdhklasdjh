# Código de Conducta

Todos los contribuyentes deben cumplir con el Código de Conducta. Se promueve
un entorno respetuoso y colaborativo. No se tolerará acoso ni comportamiento
discriminatorio.

Si experimentas o ves un comportamiento inapropiado, por favor contacta al
mantenedor del repositorio.
